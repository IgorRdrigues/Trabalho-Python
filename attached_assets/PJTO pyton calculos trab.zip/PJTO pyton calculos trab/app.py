from flask import Flask, render_template, request
from datetime import datetime

app = Flask(__name__)

def to_float(valor):
    return float(valor.replace('.', '').replace(',', '.'))

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/folha", methods=["GET", "POST"])
def folha():
    if request.method == "POST":
        nome = request.form["nome"]
        salario_bruto = to_float(request.form["salario_bruto"])
        transporte = request.form["transporte"].lower() == "s"
        dependentes = int(request.form["dependentes"])
        horas_55 = to_float(request.form["horas_55"])
        horas_100 = to_float(request.form["horas_100"])

        desconto_transporte = salario_bruto * 0.06 if transporte else 0
        inss = salario_bruto * 0.09
        salario_familia = 56.47 * dependentes if salario_bruto <= 1819.26 else 0
        valor_hora = salario_bruto / 30 / 7.2
        extra_55 = valor_hora * 1.55 * horas_55
        extra_100 = valor_hora * 2 * horas_100
        total_extras = extra_55 + extra_100
        salario_liquido = salario_bruto - desconto_transporte - inss + salario_familia + total_extras

        resultado = f"""--- CONTRACHEQUE ---
Funcionário: {nome}
Salário Bruto: R$ {salario_bruto:.2f}
Desconto INSS: R$ {inss:.2f}
Desconto VT: R$ {desconto_transporte:.2f}
Salário Família: R$ {salario_familia:.2f}
Horas Extras 55%: R$ {extra_55:.2f}
Horas Extras 100%: R$ {extra_100:.2f}
Salário Líquido: R$ {salario_liquido:.2f}"""
        return render_template("resultado.html", resultado=resultado)
    return render_template("folha.html")

@app.route("/ferias", methods=["GET", "POST"])
def ferias():
    if request.method == "POST":
        nome = request.form["nome"]
        salario_base = to_float(request.form["salario_base"])
        horas_55 = to_float(request.form["horas_55"])
        horas_100 = to_float(request.form["horas_100"])
        dias_vendidos = int(request.form["dias_vendidos"])

        valor_hora = salario_base / 30 / 7.2
        extras = (valor_hora * 1.55 * horas_55) + (valor_hora * 2 * horas_100)
        ferias_valor = salario_base + extras
        adicional_terco = ferias_valor / 3
        venda = (salario_base / 30) * dias_vendidos
        total = ferias_valor + adicional_terco + venda

        resultado = f"""--- RECIBO DE FÉRIAS ---
Funcionário: {nome}
Salário Base: R$ {salario_base:.2f}
Horas Extras 55%: R$ {valor_hora * 1.55 * horas_55:.2f}
Horas Extras 100%: R$ {valor_hora * 2 * horas_100:.2f}
Adicional de 1/3: R$ {adicional_terco:.2f}
Venda de {dias_vendidos} dias: R$ {venda:.2f}
Total a Receber: R$ {total:.2f}"""
        return render_template("resultado.html", resultado=resultado)
    return render_template("ferias.html")

@app.route("/rescisao", methods=["GET", "POST"])
def rescisao():
    if request.method == "POST":
        nome = request.form["nome"]
        salario = to_float(request.form["salario"])
        horas_55 = to_float(request.form["horas_55"])
        horas_100 = to_float(request.form["horas_100"])
        admissao = datetime.strptime(request.form["admissao"], "%Y-%m-%d")
        demissao = datetime.strptime(request.form["demissao"], "%Y-%m-%d")
        ferias_vencidas = request.form["ferias_vencidas"].lower() == "s"
        fgts = to_float(request.form["fgts"])
        vt = to_float(request.form["vt"])

        meses = (demissao.year - admissao.year) * 12 + demissao.month - admissao.month
        aviso = 30 + (min(meses // 12, 3) * 3)
        saldo_salario = (salario / 30) * demissao.day
        ferias_prop = (salario / 12) * meses
        adicional_1_3 = ferias_prop / 3
        decimo = (salario / 12) * meses
        aviso_valor = (salario / 30) * aviso
        ferias_vencidas_valor = salario + (salario / 3) if ferias_vencidas else 0
        valor_hora = salario / 30 / 7.2
        extras = (valor_hora * 1.55 * horas_55) + (valor_hora * 2 * horas_100)

        total = sum([
            saldo_salario, ferias_prop, adicional_1_3, decimo,
            aviso_valor, ferias_vencidas_valor, extras, fgts, vt
        ])

        resultado = f"""--- RECIBO DE RESCISÃO ---
Funcionário: {nome}
Saldo de Salário: R$ {saldo_salario:.2f}
Férias Proporcionais: R$ {ferias_prop:.2f}
1/3 de Férias: R$ {adicional_1_3:.2f}
13º Proporcional: R$ {decimo:.2f}
Aviso Prévio ({aviso} dias): R$ {aviso_valor:.2f}
Férias Vencidas: R$ {ferias_vencidas_valor:.2f}
Horas Extras: R$ {extras:.2f}
FGTS: R$ {fgts:.2f}
VT Não Usado: R$ {vt:.2f}
Total da Rescisão: R$ {total:.2f}"""
        return render_template("resultado.html", resultado=resultado)
    return render_template("rescisao.html")

if __name__ == "__main__":
    app.run(debug=True)
